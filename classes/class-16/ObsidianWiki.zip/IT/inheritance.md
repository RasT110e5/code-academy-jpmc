# Inheritance

Languages that support classes almost always support. This allows classes to be arranged in a hierarchy that represents "is-a-type-of" relationships. 

All the data and methods available to the parent class also appear in the child class with the same names.   This technique allows easy re-use of the same procedures and data definitions, in addition to potentially mirroring real-world relationships in an intuitive way. Rather than utilizing database tables and programming subroutines, the developer utilizes objects the user may be more familiar with: objects from their application domain.

```ad-example
For example, class Employee might inherit from class Person. Class Person might define variables "first_name" and "last_name" with method "make_full_name()". These will also be available in class Employee, which might add the variables "position" and "salary".
```

Subclasses can override the methods defined by superclasses.

In some [[object oriented programming]] languages, [[multiple inheritance]] is supported. Other languages that do not support it, provide other tools like [[interfaces]].

Can also be called subclassing.

Superclasses can often be [[abstract classes]].

## Implications in [[UML]]

In UML, inheritance is called generalization or specialization (depending on the direction of the relation).

![[class-diagram-generalization.png]]
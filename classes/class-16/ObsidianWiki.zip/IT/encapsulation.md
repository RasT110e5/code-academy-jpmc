# Encapsulation

Bundling of data with the methods that operate on that data, or the restricting of direct access to some of an object's components. 

Encapsulation is used to hide the values or state of a structured data object inside a [[classes]], preventing direct access to them by clients in a way that could expose hidden implementation details or violate state invariance maintained by the methods.

```c#
class Program
{
    public class Account
    {
        private decimal accountBalance = 500.00m;

        public decimal CheckBalance()
        {
            return this.accountBalance;
        }
    }

    static void Main()
    {
        Account myAccount = new Account();
        decimal myBalance = myAccount.CheckBalance();

        /* This Main method can check the balance via the public
         * "CheckBalance" method provided by the "Account" class 
         * but it cannot manipulate the value of "accountBalance" */
    }
}
```
# OOP

One of the many [[programming paradigms]], OOP is based on the concept of classes, which can be instantiated into objects that have data (fields known as [[attributes]] or properties) and code (procedures known as [[methods]]).

```ad-example
A "person" can be an object with attributes like height, age, name and methods like walk, talk, think.
```

## Some OOP [[programming languages]]
 - [[java]]
 - [[python]]
 - [[C++]]
 - [[python]]
 - [[C#]]
 - [[javascript]]
 - [[swift]]
 - [[kotlin]]

```ad-note
Most of these languages can be used in a non-OOP way, but it is probably best to use the best tool for a job instead of using the same tool for all jobs.
```

## Common Features

OOP solutions can be designed and implemented using different [[design patterns]].

### Shared with Non-OOP features

- [[variables]]
- [[procedures]]

### OOP features & Characteristics

- [[classes]]
- [[objects]]
- [[encapsulation]]
- [[inheritance]]
- [[polymorphism]]
- [[association]], [[aggregation]] and [[composition]]
- [[prototypes]]
- [[dynamic dispatch]]
- [[data abstraction]]
- [[open recursion]]


## Design

In order to create standards for software design, [[UML]] was created. Although it provides lots of different diagram standards, some of them are closely related to OOP, like the [[class-diagram]].
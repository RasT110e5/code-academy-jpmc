# MVC

Design pattern for the structure of programming projects. Acronym that stands for "Model, view and controller". 

Presentation Layer
- Handles user input.
- Handles system output.

Controller Layer
- Serves data from the model to the view.
- Serves data from the view to the model.

Model Layer
- Representation of business entities.

```ad-warning
As project advances, this explanation of MVC comes up short. That is why you will find more components if you look MVC up. You will learn about services and how they handle business logic and DAOs.
```

Service Layer
- Handles business logic.
- Handles data received in controllers.

DAO Layer
- Acronym for data access object
- Used to create model objects from what is received in the controller and processed by the service layer.
- Can be related to a database and handle data persistence, although this responsibility may have its own layer.

```ad-question
I do not know what is the extent of MVC. Are this variations part of it? Is there a standard for MVC I am missing?
```

A project's structure is ultimately up to the programmers in it. That is why there are variations to MVC and multiple design patterns exist for this use case. The important thing is to reach an agreement on how to organize packages in a project and have a consistent reason for each package across the project, without redundancies.
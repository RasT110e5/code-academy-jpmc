# Composition

A subset or type of [[aggregation]]. Composition implies a relationship between [[classes]] where the child is tied life-cycle-wise to the parent.  It represents a **part-of** relationship.

```ad-example
Think of a house and a room. The class room (child) cannot exist if the house (parent) class is deleted.
```

```ad-warning
There is an ongoing issue in the Internet with this concept. Some websites (including Wikipedia) do not differentiate between composition and [[aggregation]], saying that a composition represents a **has-a** relationship and do not mention composition at all. This confusion stems from composition being a subset of aggregation.
```

Compositions may exist naturally (like the house-room example) or artificially. I.e. the programmer makes them happen in code even though in the real world they do not make sense. 

```ad-example
An engine may be part of a car. In a particular system (like a dealership's, the engine without the car does not exist. 
```

## Implications in [[UML]]

![[class-diagram-composition.png]]

In this example, the head, hand and leg are part of a person and cannot exist without the person.

## Implications in code

### Java

```ad-warning
There are confusions in the Internet with the Java implementation of compositions. Remember the definition of composition and how the life-cycle of two classes is tied and think of the business requirements for the case you are working with.
```

That can mean:

- You should add the keyword [[final]] to child class attribute in the parent class, in order to make it immutable.

```java
public class Car {
	private final Engine engine;
}
```

- You should instantiate an object of the child class when declaring the attribute of a parent class.

```java
public class Car {
	private Engine enginge = new Engine();
}
```

- The constructor of the parent class has to receive the attributes of the child class, so when the parent is created, the child is always created with it.

```java
public class Engine {
	private String size;
	private int horsepower;
}

public class Car {
	private String model;
	private Enginge engine;

	Car (String model, String size; int horsepower) {  
	    this.model = model;
	    this.engine.sizeb = size;
	    this.engine.horsepower = horsepower;  
	}
}
```

- Or a combination of the previously mentioned implementations, depending on the business requirements.
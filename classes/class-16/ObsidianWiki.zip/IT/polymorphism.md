# Polymorphism

Is the provision of a single interfaces or the use of a single symbol to represent multiple different types.

The most commonly recognized major classes of polymorphism are:

-   _Ad hoc_ polymorphism: defines a common interface for an arbitrary set of individually specified types.

```ad-example
Imagine an operator `+` that may be used in the following ways:

1.  `1 + 2 = 3`
2.  `3.14 + 0.0015 = 3.1415`
3.  `1 + 3.7 = 4.7`
4.  `[1, 2, 3] + [4, 5, 6] = [1, 2, 3, 4, 5, 6]`
5.  `[true, false] + [false, true] = [true, false, false, true]`
6.  `"bab" + "oon" = "baboon"`
```

-   Parametric polymorphism: Using it, a function or a data type can be written generically so that it can handle values _identically_ without depending on their type. Such functions and data types are called generic functions and generic datatypes respectively and form the basis of generic programming.

```ad-example
function `append` that joins two lists can be constructed so that it does not care about the type of elements: it can append lists of integers, lists of real numbers, lists of strings, and so on. Let the _type variable a_ denote the type of elements in the lists. Then `append` can be typed

`forall a. [a] × [a] -> [a]`
```

-   Subtyping (also called _subtype polymorphism_ or _inclusion polymorphism_): when a name denotes instances of many different classes related by some common superclass. Subtyping can also be called subclassing or [[inheritance]].
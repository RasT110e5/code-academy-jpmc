## Imperative Programming

Using statements that change a program's state. An imperatively programmed algorithm should consist of commands for the computer to perform, step by step.

i.e. commands executed with a specific order
# Objects

In [[object oriented programming]] objects are a combination of [[variables]], [[methods]], and [[data structures]] that in [[class based programming]] are an instance of a [[classes]].
# Abstract Types

In programming languages, an abstract type is a type in a nominative type system that cannot be instantiated directly; a type that is not abstract – which can be instantiated – is called a concrete type. Every instance of an abstract type is an instance of some concrete subtype. Abstract types are also known as existential types.

In [[object oriented programming]], abstract types can be [[abstract classes]] and [[interfaces]].
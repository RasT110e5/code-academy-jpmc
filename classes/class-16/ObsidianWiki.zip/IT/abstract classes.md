# Abstract Classes

Are [[classes]] that cannot be instantiated. They are the opposite of concrete [[classes]].

They are the implementation of the concept of [[abstract types]] in [[object oriented programming]].

```java
//By default, all methods in all classes are concrete, unless the abstract keyword is used.
abstract class Demo {
    // An abstract class may include abstract methods, which have no implementation.
    abstract public int sum(int x, int y);

    // An abstract class may also include concrete methods.
    public int product(int x, int y) { return x*y; }
}
```

When combining abstraction and [[inheritance]], we can force subclasses to implement the methods of the abstract superclass. Or the other way around, we must implement the abstract methods of the superclass in the subclass.

## Implications in code

### Java

If a class has an abstract method, we will have to declare the class as abstract.

Although an abstract class cannot be instantiated, it can have constructors. Subclasses will make use of that constructor

```java
abstract class Base {
 
    // Constructor of class 1
    Base()
    {
        // Print statement
        System.out.println("Base Constructor Called");
    }
 
    // Abstract method inside class1
    abstract void fun();
}
 
// Class 2
class Derived extends Base {
 
    // Constructor of class2
    Derived()
    {
        System.out.println("Derived Constructor Called");
    }
 
    // Method of class2
    void fun()
    {
        System.out.println("Derived fun() called");
    }
}
 
// Class 3
// Main class
class GFG {
 
    // Main driver method
    public static void main(String args[])
    {
        // Creating object of class 2
        // inside main() method
        Derived d = new Derived();
        d.fun();
    }
}

/*
Output
Base Constructor Called
Derived Constructor Called
Derived fun() called
*/
```
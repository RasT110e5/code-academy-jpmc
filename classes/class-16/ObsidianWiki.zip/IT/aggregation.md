# Aggregation

A type of [[association]], aggregation relationships indicate a **has-a** relationship between two classes.

```ad-example
A university classroom, has a group of students assigned to it.
```

It is rather easy to understand, in contrast to [[composition]] which is a type of aggregation. Implications in code are not difficult to grasp.

## Implications in [[UML]]

![[class-diagram-aggregation.png]]
A car has a wheel and an engine. In this program, the engine and the wheel can exist without the car existing. In fact, an Engine inspection has an engine assigned to it as well, without having a car assigned to it.

## Implications in code

```java
public class Classroom {
	private String name;
	private Student[] students;
}
```

The class Classroom has an array of the type Students, called students, as one of its attributes. A student can be added or removed from that classroom, and if the classroom is deleted, the students will still exist, although the relationship with that classroom will be lost.
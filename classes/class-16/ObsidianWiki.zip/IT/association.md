# Association

Although one can sometimes tell the type of relationship between two classes by looking at the code, [[classes]]' relationships are explicitly indicated in [[UML]]'s' [[class-diagram]].

If two classes in a model need to communicate with each other, there must be a link between them, and that can be represented by an association (connector).

Association can be represented by a line between these classes with an arrow indicating the navigation direction. In case an arrow is on both sides, the association is known as a bidirectional association.

We can indicate the multiplicity of an association by adding multiplicity adornments to the line denoting the association. The example indicates that a Student has one or more Instructors:

A single student can associate with multiple teachers:

![[class-diagram-association.png]]

The example indicates that every Instructor has one or more Students:

![[class-diagram-association2.png]]

We can also indicate the behavior of an object in an association (i.e., the role of an object) using role names:

![[class-diagram-association3.png]]

There are subsets of associations called [[aggregation]] and [[composition]].

![[association-categories.png]]

## Implications in code

```java
class Bank {

    private String name;

    Bank(String name) {
        this.name = name;
    }

    public String getBankName() {
        return this.name;
    }

}

class Employee {

    // Attributes of employee

    private String name;

    // Employee name

    Employee(String name)

    {

        // This keyword refers to current instance itself

        this.name = name;

    }

    // Method of Employee class

    public String getEmployeeName()

    {

        // returning the name of employee

        return this.name;

    }

}

class main {

    public static void main(String[] args)

    {

        // Creating objects of bank and Employee class

        Bank bank = new Bank("ICICI");

        Employee emp = new Employee("Ridhi");

        // Print and display name and
        // corresponding bank of employee.
        // This is the association.

        System.out.println(emp.getEmployeeName()
                           + " is employee of "
                           + bank.getBankName());
    }

}
```
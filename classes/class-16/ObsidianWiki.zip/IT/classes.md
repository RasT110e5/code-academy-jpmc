# Classes

Template for the creation of a [[objects]].
Abstraction of [[objects]], and therefore a big part of [[object oriented programming]].

Normally they represent entities or concepts, they are nouns.

They can have [[attributes]] and/or [[procedures]], called methods in [[object oriented programming]].

```ad-example
The class 'person' can instantiate objects like 'student', 'teacher'. A person will have a name, an age and will be able to talk and get older, amongst other attributes and methods.
```

In order to avoid instantiation of a class, [[abstract classes]] are used.
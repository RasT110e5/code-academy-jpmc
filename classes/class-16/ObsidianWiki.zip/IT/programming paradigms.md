# Programming Paradigms

A programming [[paradigm]] is a way to classify [[programming languages]] based on their features. Languages in the same paradigm share similar concepts, tools and implementations, although there are still several differences among them.

These are **some** of them:

- [[imperative]]
	- [[object oriented programming]]
	- [[procedural]]
- [[declarative]]
	- [[functional]]
	- [[logic]]
	- [[mathematical]]
	- [[reactive]]

Although it is easier to think of languages as tools that should be used in specific circumstances, in specific ways, to solve specific problems; languages will often have features that go beyond the paradigm they have been placed in.
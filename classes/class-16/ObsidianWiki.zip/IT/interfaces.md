# Interface

Is a kind of [[abstract types]] that is used to specify the behavior of a class. It therefore cannot be instantiated.

## In [[java]]

It allows for  [[multiple inheritance]] in a way, since a class can implement as many interfaces as it wants, while extending only from one superclass.

Interfaces can have [[final]] [[attributes]], and [[abstract methods]].
Generate a system for managing the exchange of goods and services for points.

## Use Case

![[use-case-exchange-ex.png]]

## Class Diagram
![[class-diagram-exchange-ex.png]]